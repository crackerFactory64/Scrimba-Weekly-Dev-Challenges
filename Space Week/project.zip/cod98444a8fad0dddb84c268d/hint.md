Check out:
 
- join()
- new fill() https://scrimba.com/learn/frontend/aside-fill-co5634dc093899782b806b500