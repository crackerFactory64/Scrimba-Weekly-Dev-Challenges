Check out: 

- for loops
- createElement()
- Setting the style property on an element: https://www.javascripttutorial.net/javascript-dom/javascript-style/


For the "dark side of the planets" stretch challenge: 
Check out conic gradients: https://www.youtube.com/watch?v=zBKtClCdZfQ