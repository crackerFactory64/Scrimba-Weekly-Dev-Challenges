Check out:

- for loops
- createElement()
- Reduce() https://scrimba.com/learn/frontend/aside-arrayreduce-co430464b9ec75b4d30f20b0f